/**
 * 
 */
package org.ognl.test.objects;


/**
 */
public class FirstBean extends BaseBean
{
    
    public String getName()
    {
        return "FirstBean";
    }

}
