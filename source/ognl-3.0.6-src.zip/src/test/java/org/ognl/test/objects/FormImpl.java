package org.ognl.test.objects;

/**
 *
 */
public class FormImpl extends ComponentImpl implements IForm {
    
}
