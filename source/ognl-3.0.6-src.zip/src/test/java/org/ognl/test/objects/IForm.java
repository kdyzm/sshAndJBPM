package org.ognl.test.objects;

/**
 *
 */
public interface IForm extends IComponent {
    
}
