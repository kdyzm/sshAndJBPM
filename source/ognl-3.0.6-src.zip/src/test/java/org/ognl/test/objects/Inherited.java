package org.ognl.test.objects;

/**
 *
 */
public interface Inherited {

    String getMyString();
}
