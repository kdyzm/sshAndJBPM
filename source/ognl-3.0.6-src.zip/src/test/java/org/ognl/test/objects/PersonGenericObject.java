package org.ognl.test.objects;

/**
 *
 */
public class PersonGenericObject implements GenericObject {

    public int getId()
    {
        return 1;
    }

    public String getDisplayName()
    {
        return "Henry Collins";
    }
}
