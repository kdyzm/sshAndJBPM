/**
 * 
 */
package org.ognl.test.objects;


/**
 */
public class SecondBean extends BaseBean
{
    public String getName()
    {
        return "SecondBean";
    }

}
