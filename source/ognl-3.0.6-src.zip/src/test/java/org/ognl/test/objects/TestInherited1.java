package org.ognl.test.objects;

/**
 *
 */
public class TestInherited1 implements Inherited {

    public String getMyString()
    {
        return "inherited1";
    }
}
